﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;


namespace SideScrollerGame
{
    internal class Program
    {

        /* ÇALIŞMIYOR */ /* ÇALIŞMIYOR */ /* ÇALIŞMIYOR */ /* ÇALIŞMIYOR */
        #region Fields
        #endregion
        static void Main(string[] args)
        {
            GameWindowMap gwm = new GameWindowMap();
            Stats st = new Stats();
            PlayerCharacter pc = new PlayerCharacter();
            Arrows arr = new Arrows();
            Gallons gln = new Gallons();

            Inputs inp = new Inputs();
            Console.CursorVisible = false;
            Console.Clear();
            gwm.DrawGameWindow();
            gwm.DrawFloor();
            st.DrawStatsScore(st.Health, st.Score);
            pc.DrawPlayer();

            gln.CreateGallons();

            //10 adet gallondan birkaçı hatalı olarak hep saha dışına tepeye çiziliyor onları silmek için.
            gln.DeleteFalsePlacedGallons();

            Thread rndMoveArrowTHREAD1 = new Thread(arr.MoveArrows1);
            Thread rndMoveArrowTHREAD2 = new Thread(arr.MoveArrows2);
            Thread rndMoveArrowTHREAD3 = new Thread(arr.MoveArrows3);

            Thread handleinputThread = new Thread(inp.HandleInput);

            Thread rndLocationArrowGenTHREAD1 = new Thread(arr.RandomLocationArrowGenerator1);

            Thread rndLocationArrowGenTHREAD2 = new Thread(arr.RandomLocationArrowGenerator2);

            Thread rndLocationArrowGenTHREAD3 = new Thread(arr.RandomLocationArrowGenerator3);

            rndLocationArrowGenTHREAD1.Start();
            rndLocationArrowGenTHREAD2.Start();
            rndLocationArrowGenTHREAD3.Start();
            rndMoveArrowTHREAD3.Start();
            rndMoveArrowTHREAD2.Start();
            rndMoveArrowTHREAD1.Start();
            handleinputThread.Start();


        }


    }
}
