﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Gallons
    {
        private readonly Random rndG = new Random();


        public byte[,] XY = new byte[15, 2];

        public byte[,] XY1 { get => XY; set => XY = value; }

        private bool GameOverRestartExit;
        private readonly int playerPosX;
        private readonly int playerPosY;
        private int ArrowPosX1;
        private int ArrowPosY1;
        private int ArrowPosX2;
        private int ArrowPosY2;
        private int ArrowPosX3;
        private int ArrowPosY3;
        public int ArrowPosX11 { get => ArrowPosX1; set => ArrowPosX1 = value; }
        public int ArrowPosY11 { get => ArrowPosY1; set => ArrowPosY1 = value; }
        public int ArrowPosX21 { get => ArrowPosX2; set => ArrowPosX2 = value; }
        public int ArrowPosY21 { get => ArrowPosY2; set => ArrowPosY2 = value; }
        public int ArrowPosX31 { get => ArrowPosX3; set => ArrowPosX3 = value; }
        public int ArrowPosY31 { get => ArrowPosY3; set => ArrowPosY3 = value; }

        public int score;
        public int health;

        public Gallons(Arrows arr, PlayerCharacter pc, Inputs inp, Stats st)
        {
            this.ArrowPosX11 = arr.ArrowPosX1;
            this.ArrowPosY11 = arr.ArrowPosY1;
            this.ArrowPosX21 = arr.ArrowPosX2;
            this.ArrowPosY21 = arr.ArrowPosY2;
            this.ArrowPosX31 = arr.ArrowPosX3;
            this.ArrowPosY31 = arr.ArrowPosY3;

            this.playerPosX = pc.PlayerPosX;
            this.playerPosY = pc.PlayerPosY;

            this.GameOverRestartExit = inp.GameOverRestartExit;

            this.score = st.Score;
            this.health = st.Health;
        }

        public Gallons()
        {
        }

        public void CreateGallons(Random rndG)
        {
            byte x;
            byte y;
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < 15; i++)
                {
                    if (j == 0)
                    {
                        lock (Console.Out)
                        {
                            x = Convert.ToByte(rndG.Next(17, 89));
                            XY1[i, 0] = x;
                        }
                    }

                    else if (j == 1)
                    {
                        lock (Console.Out)
                        {
                            y = Convert.ToByte(rndG.Next(9, 18));
                            XY1[i, 1] = y;
                        }
                    }
                }
                for (int i = 0; i < XY1.GetLength(0); i++)
                {
                    lock (Console.Out)
                    {
                        Console.SetCursorPosition(XY1[i, 0], XY1[i, 1]);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write("o");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
            }
        }
        public void RefreshGallonsHitByArrows(byte[,] XY)
        {
            Stats st = new Stats();

            for (int i = 0; i < XY.GetLength(0); i++)
            {
                if (playerPosX == XY[i, 0] && playerPosY == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        ++score;
                        st.DrawStatsScore(health, score);
                        XY[i, 0] = 0;
                        return;
                    }
                }
                else if (ArrowPosX2 + 8 == XY[i, 0] && ArrowPosY2 == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                        return;
                    }
                }
                else if (ArrowPosX1 + 8 == XY[i, 0] && ArrowPosY1 == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                        return;
                    }
                }
                else if (ArrowPosX3 + 8 == XY[i, 0] && ArrowPosY3 == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                        return;
                    }
                }

            }
        }
        public void RefreshGallonsHitByFireBullets(byte[,] XY, int i)
        {
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                Console.Write("o");
                Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void DeleteFalsePlacedGallons()
        {
            Console.SetCursorPosition(0, 0);
            string deletefalseplacedGallons = new string(' ', 100);
            Console.Write(deletefalseplacedGallons);
        }


    }
}
