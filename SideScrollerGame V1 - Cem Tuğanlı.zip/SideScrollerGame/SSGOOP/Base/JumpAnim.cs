﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    internal class JumpAnim
    {
        private int playerPosX;
        private int playerPosY;

        public JumpAnim()
        {
        }

        public JumpAnim(PlayerCharacter pc)
        {
            this.playerPosX = pc.PlayerPosX;
            this.playerPosY = pc.PlayerPosY;
        }
        public void Jump()
        {
            bool landing = false;
            while (!landing)
            {
                //nereye ve ne kadarlık alana lock koyduğuna dikkat et yoksa oyun gereksiz kasar
                lock (Console.Out)
                {
                    // Erase the previous position of the player
                    Console.SetCursorPosition(playerPosX, playerPosY);
                    Console.Write(' ');

                    // Move the player to the new position
                    Console.SetCursorPosition(playerPosX, --playerPosY);
                    Console.Write('0');
                }

                Thread.Sleep(100);
                if (playerPosY == 9)
                {
                    while (!landing)
                    {
                        lock (Console.Out)
                        {
                            // Erase the previous position of the player
                            Console.SetCursorPosition(playerPosX, playerPosY);
                            Console.Write(' ');

                            // Move the player to the new position
                            Console.SetCursorPosition(playerPosX, ++playerPosY);
                            Console.Write('0');
                        }
                        Thread.Sleep(100);
                        if (playerPosY == 18)
                        {
                            landing = true;
                        }
                    }
                }
            }
        }

    }
}
