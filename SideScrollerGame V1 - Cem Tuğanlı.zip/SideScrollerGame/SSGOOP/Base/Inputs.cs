﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Inputs
    {
        private bool gameOverRestartExit = false;

        public bool GameOverRestartExit { get => gameOverRestartExit; set => gameOverRestartExit = value; }

        private byte[,] XY;
        public Inputs(Gallons gln)
        {
            this.XY = gln.XY;
        }

        public Inputs()
        {
        }

        public void HandleInput()
        {
            //while parantezinde gameOverRestartExit sistemini kurmasaydım input için 2 adet key tıklaması istenecekti çünkü hem while içersindeki ReadKey(true) hem de GameoverRestartExit() içersindeki ReadKey() input isteyecekti ama yine de 2 kez çift tıkladıktan sonra ancak 1 kez input algılayabiliyor
            while (GameOverRestartExit == false)
            {
                JumpAnim jm = new JumpAnim();
                FireBullets fb = new FireBullets();
                PlayerCharacter pc = new PlayerCharacter();
                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                if (keyInfo.Key == ConsoleKey.Spacebar)
                {
                    //Delete remnant A character on screen when reset position to playerPosY=0
                    Thread jumpThread = new Thread(jm.Jump);
                    jumpThread.Start();
                }
                else if (keyInfo.Key == ConsoleKey.F)
                {
                    // Fire a projectile horizontally
                    Thread projectileThread = new Thread(() => fb.Fire(XY));
                    projectileThread.Start();
                }
                else if ((keyInfo.Key == ConsoleKey.A) || (keyInfo.Key == ConsoleKey.D))
                {
                    Thread movePlayerThread = new Thread(() => pc.MovePlayer(keyInfo.Key));
                    movePlayerThread.Start();
                }
            }
        }
    }
}
