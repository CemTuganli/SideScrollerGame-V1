﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Stats
    {
        private static readonly Stats st;
        public static Stats St
        {
            get { return st; }
        }


        private byte health = 3;
        private byte score = 0;

        private readonly int playerPosX;
        private readonly int playerPosY;

        private bool GameOverRestartExit;
        public byte Health { get => health; set => health = value; }
        public byte Score { get => score; set => score = value; }

        private int ArrowPosX1;
        private int ArrowPosY1;
        private int ArrowPosX2;
        private int ArrowPosY2;
        private int ArrowPosX3;
        private int ArrowPosY3;
        public int ArrowPosX11 { get => ArrowPosX1; set => ArrowPosX1 = value; }
        public int ArrowPosY11 { get => ArrowPosY1; set => ArrowPosY1 = value; }
        public int ArrowPosX21 { get => ArrowPosX2; set => ArrowPosX2 = value; }
        public int ArrowPosY21 { get => ArrowPosY2; set => ArrowPosY2 = value; }
        public int ArrowPosX31 { get => ArrowPosX3; set => ArrowPosX3 = value; }
        public int ArrowPosY31 { get => ArrowPosY3; set => ArrowPosY3 = value; }



        public Stats(Arrows arr, PlayerCharacter pc, Inputs inp) 
        {
            this.ArrowPosX11 = arr.ArrowPosX1;
            this.ArrowPosY11 = arr.ArrowPosY1;
            this.ArrowPosX21 = arr.ArrowPosX2;
            this.ArrowPosY21 = arr.ArrowPosY2;
            this.ArrowPosX31 = arr.ArrowPosX3;
            this.ArrowPosY31 = arr.ArrowPosY3;

            this.playerPosX = pc.PlayerPosX;
            this.playerPosY = pc.PlayerPosY;

            this.GameOverRestartExit = inp.GameOverRestartExit;
        }

        public Stats()
        {
        }

        public void DamageWarningHealthDecrease()
        {
            if (Health <= 0)
            {
                lock (Console.Out)
                {
                    Health = 0;
                    GameoverRestartExit();
                }
            }
            else if ((ArrowPosX11 == playerPosX && ArrowPosY11 == playerPosY) || (ArrowPosX11 + 1 == playerPosX && ArrowPosY11 == playerPosY) || (ArrowPosX11 + 2 == playerPosX && ArrowPosY11 == playerPosY) || (ArrowPosX11 + 3 == playerPosX && ArrowPosY11 == playerPosY))
            {
                lock (Console.Out)
                {
                    --Health;
                    DrawStatsScore(Health, Score);
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);

                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                    return;
                }
            }
            else if ((ArrowPosX21 == playerPosX && ArrowPosY21 == playerPosY) || (ArrowPosX21 + 1 == playerPosX && ArrowPosY21 == playerPosY) || (ArrowPosX21 + 2 == playerPosX && ArrowPosY21 == playerPosY) || (ArrowPosX21 + 3 == playerPosX && ArrowPosY21 == playerPosY))
            {
                lock (Console.Out)
                {
                    --Health;
                    DrawStatsScore(Health, Score);
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);


                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                    return;
                }
            }
        }
        public void RestorePlayerGameValues()
        {
            Health = 3;
            Score = 0;
            GameOverRestartExit = false;
        }
        public void GameoverRestartExit()
        {
            
            lock (Console.Out)
            {
                //while döngüsü sayesinde her input denemesinde okların vs. 1 adım hareket etmesi sorununu çözdüm
                bool ask = true;
                while (ask)
                {
                    //Bu booleanı başa alarak input exit restart olayını 1 kez 2 input girişi denemesine düşürdüm. 
                    GameOverRestartExit = true;

                    Console.CursorVisible = false;
                    Console.SetCursorPosition(46, 10);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("GAME OVER!!!!");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.SetCursorPosition(28, 12);
                    Console.WriteLine("Do you want to restart the game or exit to main menu?");
                    Console.SetCursorPosition(40, 14);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("    Restart: R   Exit: E");
                    Console.ForegroundColor = ConsoleColor.White;

                    ConsoleKeyInfo keyinfo = Console.ReadKey(true);
                    if (keyinfo.KeyChar == 'r' || keyinfo.KeyChar == 'R')
                    {
                        RestorePlayerGameValues();
                        Console.Clear();
                        ask = false;
                    }
                    else if (keyinfo.KeyChar == 'e' || keyinfo.KeyChar == 'E')
                    {
                        RestorePlayerGameValues();
                        Console.Clear();
                        ask = false;
                    }
                    else
                    {
                        RestartExitWrongKeyWarning();
                    }
                }
            }
        }
        public void RestartExitWrongKeyWarning()
        {
            lock (Console.Out)
            {
                byte count = 0;
                Console.Beep();
                while (count <= 5)
                {
                    Console.SetCursorPosition(40, 16);
                    System.Threading.Thread.Sleep(150);
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.Write("Please Enter A Valid Key!");
                    System.Threading.Thread.Sleep(150);
                    Console.SetCursorPosition(40, 16);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("Please Enter A Valid Key!");
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }
                Console.SetCursorPosition(40, 16);
                Console.Write("                         ");
                Console.ForegroundColor = ConsoleColor.White;

            }
        }
        public void WarningMessage()
        {

            byte count = 0;
            Console.Beep();
            while (count <= 5)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }

            }
            lock (Console.Out)
            {
                Console.SetCursorPosition(5, 1);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("                      ");
            }
        }
        public void FlickeringHealth()
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            byte count1 = 0;
            while (count1 <= 4)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Health : {Health}  ");
                    Thread.Sleep(50);
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write($"Health : {Health}  ");
                    Thread.Sleep(50);
                }
                ++count1;

            }
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {Health}  ");
                Console.Write($"Score : {Score}");
            }
        }
        public void DrawStatsScore(int health, int score)
        {
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {health}  ");
                Console.Write($"Score : {score}");
            }
        }

    }
}
