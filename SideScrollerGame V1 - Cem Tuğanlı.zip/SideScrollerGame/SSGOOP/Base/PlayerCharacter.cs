﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class PlayerCharacter
    {
        private int playerPosX = 18;
        private int playerPosY = 18;
        public int PlayerPosX { get => playerPosX; set => playerPosX = value; }
        public int PlayerPosY { get => playerPosY; set => playerPosY = value; }

        public void DrawPlayer()
        {
            lock (Console.Out)
            {
                Console.SetCursorPosition(PlayerPosX, PlayerPosY);
                Console.Write("0");
            }
        }

        public void MovePlayer(ConsoleKey keyInfo)
        {
            if (keyInfo == ConsoleKey.A)
            {
                lock (Console.Out)
                {
                    if (PlayerPosX >= 14)
                    {
                        Console.SetCursorPosition(PlayerPosX, PlayerPosY);
                        Console.Write('0');
                        Console.Write(' ');
                    }
                    else
                    {
                        return;
                    }
                }
            }
            else if (keyInfo == ConsoleKey.D)
            {
                lock (Console.Out)
                {
                    if (PlayerPosX <= 94)
                    {
                        Console.SetCursorPosition(PlayerPosX, PlayerPosY);
                        Console.Write(' ');
                        Console.SetCursorPosition(PlayerPosX, PlayerPosY);
                        Console.Write('0');
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }
    }
    
}
