﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Arrows
    {
        private Random rnd = new Random(DateTime.UtcNow.Millisecond);

        public Stats st;
        public Gallons gln;
        public Arrows(Stats st) 
        {
            this.st = st;
        }

        private int arrowPosX1;
        private int arrowPosY1;
        private int arrowPosX2;
        private int arrowPosY2;
        private int arrowPosX3;
        private int arrowPosY3;

        private byte[,] XY;

        public int ArrowPosX1 { get => arrowPosX1; set => arrowPosX1 = value; }
        public int ArrowPosY1 { get => arrowPosY1; set => arrowPosY1 = value; }
        public int ArrowPosX2 { get => arrowPosX2; set => arrowPosX2 = value; }
        public int ArrowPosY2 { get => arrowPosY2; set => arrowPosY2 = value; }
        public int ArrowPosX3 { get => arrowPosX3; set => arrowPosX3 = value; }
        public int ArrowPosY3 { get => arrowPosY3; set => arrowPosY3 = value; }

        public Arrows(Gallons gln) 
        {
            this.XY = gln.XY;
        }

        public Arrows()
        {
        }

        public void RandomLocationArrowGenerator1()
        {
            //Okların nereye kadar ilerleyeceklerini bu döngülerdeki süreler Sleep süreleri belirliyor
                //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
                ArrowPosX1 = rnd.Next(80, 85);
                ArrowPosY1 = rnd.Next(9, 12);

                
        }

        private void RefreshBeforeArrowDisappear1()
        {
            lock (Console.Out)
            {
                for (int i = 0; i < XY.GetLength(0); i++)
                {
                    if ((arrowPosX1 == XY[i, 0] || arrowPosX1 + 1 == XY[i, 0] || arrowPosX1 + 2 == XY[i, 0] || arrowPosX1 + 3 == XY[i, 0]) && arrowPosY1 == XY[i, 1])
                    {
                        Thread RefreshGallonsThread = new Thread(() => gln.RefreshGallonsHitByArrows(XY));
                    }
                } 
            }
        }

        public void RandomLocationArrowGenerator2()
        {
                //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
                ArrowPosX2 = rnd.Next(80, 85);
                ArrowPosY2 = rnd.Next(15, 19);

                lock (Console.Out)
                {
                    Console.SetCursorPosition(ArrowPosX2 - 3, ArrowPosY2);
                    Console.Write("     ");

                }
        }

        private void RefreshBeforeArrowDisappear2()
        {
            lock (Console.Out)
            {
                for (int i = 0; i < XY.GetLength(0); i++)
                {
                    if ((arrowPosX2 == XY[i, 0] || arrowPosX2 + 1 == XY[i, 0] || arrowPosX2 + 2 == XY[i, 0] || arrowPosX2 + 3 == XY[i, 0]) && arrowPosY2 == XY[i, 1])
                    {
                        Thread RefreshGallonsThread = new Thread(() => gln.RefreshGallonsHitByArrows(XY));
                    }
                } 
            }
        }

        public void RandomLocationArrowGenerator3()
        {
                //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
                ArrowPosX3 = rnd.Next(80, 85);
                ArrowPosY3 = rnd.Next(12, 15);


                lock (Console.Out)
                {
                    Console.SetCursorPosition(ArrowPosX3 - 3, ArrowPosY3);
                    Console.Write("     ");

                }

                /*//lock (Console.Out)
                //{
                //    if ((ArrowPosX1 - 2 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 - 1 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 1 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 2 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2))
                //    {
                //        arrowPosY1 += 1;
                //    }
                //    else if ((ArrowPosX1 - 2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 - 1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2))
                //    {
                //        arrowPosY1 -= 1;
                //    }
                //    else if ((ArrowPosX2 - 2 == ArrowPosX3 && ArrowPosY2 == ArrowPosY3) || (ArrowPosX2 - 1 == ArrowPosX3 && ArrowPosY2 == ArrowPosY3) || (ArrowPosX2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX2 + 1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX2 + 2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2))
                //    {
                //        arrowPosY2 -= 2;
                //    }
                //}*/
        }

        private void RefreshBeforeArrowDisappear3()
        {
            lock (Console.Out)
            {
                for (int i = 0; i < XY.GetLength(0); i++)
                {
                    if ((arrowPosX3 == XY[i, 0] || arrowPosX3 + 1 == XY[i, 0] || arrowPosX3 + 2 == XY[i, 0] || arrowPosX3 + 3 == XY[i, 0]) && arrowPosY3 == XY[i, 1])
                    {
                        Thread RefreshGallonsThread = new Thread(() => gln.RefreshGallonsHitByArrows(XY));
                    }
                } 
            }
        }

        public void MoveArrows1()
        {
            while (ArrowPosX1 > 7)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(ArrowPosX1, ArrowPosY1);
                    Console.Write("  ");
                    Console.SetCursorPosition(ArrowPosX1 - 2, ArrowPosY1);
                    Console.Write("<--");
                }

                --ArrowPosX1;
                System.Threading.Thread.Sleep(25);
                Thread DamageThread = new Thread(st.DamageWarningHealthDecrease);
                System.Threading.Thread.Sleep(25);

                Thread RefreshGallonsThread = new Thread(() => gln.RefreshGallonsHitByArrows(XY));
                DamageThread.Start();
                RefreshGallonsThread.Start();
                lock (Console.Out)
                {
                    if (ArrowPosX1 <= 11)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                    {
                        //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                        //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                        //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                        //repairLeftWallThread.Start();
                        Console.SetCursorPosition(ArrowPosX1 - 3, ArrowPosY1);
                        Console.Write("     ");
                        RandomLocationArrowGenerator1();
                    }

                }

            }
        }
        public void MoveArrows2()
        {
            while (ArrowPosX2 > 7)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(ArrowPosX2, ArrowPosY2);
                    Console.Write("  ");
                    Console.SetCursorPosition(ArrowPosX2 - 2, ArrowPosY2);
                    Console.Write("<--");
                }

                --ArrowPosX2;
                Thread DamageThread = new Thread(st.DamageWarningHealthDecrease);
                DamageThread.Start();
                System.Threading.Thread.Sleep(28);

                Thread RefreshGallonsThread = new Thread(() => gln.RefreshGallonsHitByArrows(gln.XY1));
                RefreshGallonsThread.Start();
                System.Threading.Thread.Sleep(28);
                lock (Console.Out)
                {
                    if (ArrowPosX2 <= 11)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                    {
                        //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                        //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                        //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                        //repairLeftWallThread.Start();
                        Console.SetCursorPosition(ArrowPosX2 - 3, ArrowPosY2);
                        Console.Write("     ");
                        RandomLocationArrowGenerator2();
                    }

                }
            }
        }

        public void MoveArrows3()
        {
            while (ArrowPosX3 > 6)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(ArrowPosX3, ArrowPosY3);
                    Console.Write("  ");
                    Console.SetCursorPosition(ArrowPosX3 - 2, ArrowPosY3);
                    Console.Write("<--");
                }
                --ArrowPosX3;
                Thread DamageThread = new Thread(st.DamageWarningHealthDecrease);
                DamageThread.Start();
                System.Threading.Thread.Sleep(31);

                Thread RefreshGallonsThread = new Thread(() => gln.RefreshGallonsHitByArrows(gln.XY1));
                RefreshGallonsThread.Start();
                System.Threading.Thread.Sleep(31);

                lock (Console.Out)
                {
                    if (ArrowPosX3 <= 11)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                    {
                        //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                        //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                        //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                        //repairLeftWallThread.Start();
                        Console.SetCursorPosition(ArrowPosX3 - 3, ArrowPosY3);
                        Console.Write("     ");
                        RandomLocationArrowGenerator3();
                    }
                }
            }
        }
    }
}
