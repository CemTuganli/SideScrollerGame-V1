﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace SideScrollerGame
{
    internal class FireBullets
    {
        public readonly List<List<int>> bulletList = new List<List<int>>();
        public Gallons gln;
        private int playerPosX;
        private int playerPosY;

        public FireBullets()
        {
        }

        public FireBullets(PlayerCharacter pc)
        {
            this.playerPosX = pc.PlayerPosX;
            this.playerPosY = pc.PlayerPosY;
        }

        public void Fire(byte[,] XY)
        {
            //initialize 2 dimentional list
            for (int j = 0; j < 100; j++)
            {
                bulletList.Add(new List<int> { 0, 0 }); // each bullet has two values, X and Y position
            }
            int projectilePosX = playerPosX; // Starting X position of the projectile
            int projectilePosY = playerPosY; // Y position of the projectile is the same as the player's
            int k = 0;
            while (projectilePosX < 101)
            {
                lock (Console.Out)
                {
                    // Erase the previous position of the projectile
                    lock (Console.Out)
                    {
                        // Move the projectile to the new position
                        //projectilePosX+1 yapsam "--" 2 adet mermi gödnderiyor ve sağ duvara ulaşabiliyor silinmiyor galonlar refresh ediyor
                        //++projectilePosX yaparsam mermi daha hızlı ilerliyor ama gallonlar refresh etmiyor(teması algılamıyor olabilirler)
                        Console.SetCursorPosition(projectilePosX, projectilePosY);
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.Write('-');
                        Console.ForegroundColor = ConsoleColor.White;
                        bulletList[k][0] = projectilePosX;
                        bulletList[k][1] = projectilePosY;
                        Console.SetCursorPosition(projectilePosX - 1, projectilePosY);
                        Console.Write(' ');

                        ++k;
                    }

                    if (k >= 100)
                    {
                        break;
                    }
                    lock (Console.Out)
                    {
                        for (int i = 0; i < XY.GetLength(0); i++)
                        {
                            if (projectilePosX - 3 == XY[i, 0] && projectilePosY == XY[i, 1])
                            {   
                                Thread RefreshGallonsHitByFireBulletsTHREAD = new Thread(() => gln.RefreshGallonsHitByFireBullets(XY, i));
                                RefreshGallonsHitByFireBulletsTHREAD.Start();
                                break;
                            }
                        }
                    }
                }

                Thread.Sleep(50);
                projectilePosX++;
                if (projectilePosX == 100)
                {
                    Thread clearThread = new Thread(ClearRemnants.ClearBulletsOnRightWall);
                    clearThread.Start();
                }
            }
        }

        internal void Fire(object xY1)
        {
            throw new NotImplementedException();
        }
    }
}
