﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    internal class GameWindowMap
    {
        //bunlar static olabilir
        public static void DrawGameWindow()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            const byte height = 20;
            const byte width = 100;
            Console.CursorTop = 2;
            Console.CursorLeft = 5;
            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    if (j <= 1)
                    {
                        Console.Write("#");
                    }
                    else if ((j >= 1 && i <= 2) || (j > 1 && i >= 97))
                    {
                        Console.Write("#");
                    }
                    else if (j > 17)
                    {
                        Console.Write("#");
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }
                Console.CursorLeft = 5;
                ++Console.CursorTop;
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void DrawFloor()
        {
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.CursorTop = 19;
                Console.CursorLeft = 8;
                string floor = new string('_', 94);
                Console.Write(floor);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    }
}
