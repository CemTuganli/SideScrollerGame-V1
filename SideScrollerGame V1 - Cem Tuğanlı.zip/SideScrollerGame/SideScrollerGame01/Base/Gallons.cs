﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Gallons
    {

        private static readonly Random rndG = new Random();

        public static byte[,] XY = new byte[5, 2];

        public static byte[,] XY1 { get => XY; set => XY = value; }

        public static void CreateGallons()
        {
            byte x;
            byte y;
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < 5; i++)
                {
                    if (j == 0)
                    {
                        lock (Console.Out)
                        {
                            x = Convert.ToByte(rndG.Next(17, 89));
                            XY1[i, 0] = x;
                        }
                    }

                    else if (j == 1)
                    {
                        lock (Console.Out)
                        {
                            y = Convert.ToByte(rndG.Next(10, 19));
                            XY1[i, 1] = y;
                        }
                    }
                }
                for (int i = 0; i < XY1.GetLength(0); i++)
                {
                    lock (Console.Out)
                    {
                        Console.SetCursorPosition(XY1[i, 0], XY1[i, 1]);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write("o");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
            }
        }
        public static void RefreshGallonsHitByArrows(byte[,] XY)
        {
            
            Stats st = new Stats();
            Arrows ar = new Arrows();

            for (int i = 0; i < XY.GetLength(0); i++)
            {
                if (PlayerCharacter.playerPosX == XY[i, 0] && PlayerCharacter.playerPosY == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        ++Stats.Score;
                        Stats.DrawStatsScore(Stats.Health, Stats.Score);
                        XY[i, 0] = 0;
                        return;
                    }
                }
                else if (Arrows.ArrowPosX2 + 8 == XY[i, 0] && Arrows.ArrowPosY2 == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                        return;
                    }
                }
                else if (Arrows.ArrowPosX1 + 8 == XY[i, 0] && Arrows.ArrowPosY1 == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                        return;
                    }
                }

            }
        }
        public static void RefreshGallonsHitByFireBullets(byte[,] XY, int i)
        {
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                Console.Write("o");
                Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public static void DeleteFalsePlacedGallons()
        {
            Console.SetCursorPosition(0, 0);
            string deletefalseplacedGallons = new string(' ', 100);
            Console.Write(deletefalseplacedGallons);
        }
    }
}
