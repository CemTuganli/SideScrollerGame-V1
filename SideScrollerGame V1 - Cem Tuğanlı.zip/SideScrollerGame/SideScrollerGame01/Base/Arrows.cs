﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Arrows
    {
        private static Random rnd1 = new Random(DateTime.UtcNow.Millisecond);
        private static Random rnd2 = new Random();

        private static int arrowPosX1;
        private static int arrowPosY1;
        private static int arrowPosX2;
        private static int arrowPosY2;

        public static int ArrowPosX1 { get => arrowPosX1; set => arrowPosX1 = value; }
        public static int ArrowPosY1 { get => arrowPosY1; set => arrowPosY1 = value; }
        public static int ArrowPosX2 { get => arrowPosX2; set => arrowPosX2 = value; }
        public static int ArrowPosY2 { get => arrowPosY2; set => arrowPosY2 = value; }

        public static void RandomLocationArrowGenerator1()
        {
            //Okların nereye kadar ilerleyeceklerini bu döngülerdeki süreler Sleep süreleri belirliyor
            while (true)
            {
                //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
                ArrowPosX1 = rnd1.Next(75, 90);
                ArrowPosY1 = rnd1.Next(15, 19);
                System.Threading.Thread.Sleep(9000);
            }
        }
        public static void RandomLocationArrowGenerator2()
        {
            while (true)
            {
                //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
                ArrowPosX2 = rnd2.Next(75, 90);
                ArrowPosY2 = rnd2.Next(15, 19);
                System.Threading.Thread.Sleep(9000);
            }
        }
        public static void MoveArrows1()
        {
            while (ArrowPosX1 > 7)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(ArrowPosX1, ArrowPosY1);
                    Console.Write("  ");
                    Console.SetCursorPosition(ArrowPosX1 - 2, ArrowPosY1);
                    Console.Write("<--");
                }

                --ArrowPosX1;
                System.Threading.Thread.Sleep(50);
                Thread DamageThread = new Thread(Stats.DamageWarningHealthDecrease);
                System.Threading.Thread.Sleep(50);

                Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
                DamageThread.Start();
                RefreshGallonsThread.Start();
                if (ArrowPosX1 <= 10)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                {
                    //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                    //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                    //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                    Thread clearArrowThread = new Thread(ClearRemnants.ClearArrowsOnLeftWall);

                    //repairLeftWallThread.Start();
                    clearArrowThread.Start();
                }

            }
        }
        public static void MoveArrows2()
        {
            Stats st = new Stats();
            ClearRemnants cr = new ClearRemnants();
            Gallons gl = new Gallons(); 
            while (ArrowPosX2 > 7)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(ArrowPosX2, ArrowPosY2);
                    Console.Write("  ");
                    Console.SetCursorPosition(ArrowPosX2 - 2, ArrowPosY2);
                    Console.Write("<--");
                }
                --ArrowPosX2;
                Thread DamageThread = new Thread(Stats.DamageWarningHealthDecrease);
                DamageThread.Start();
                System.Threading.Thread.Sleep(50);

                Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
                RefreshGallonsThread.Start();
                System.Threading.Thread.Sleep(50);

                if (ArrowPosX2 <= 10)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                {
                    //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                    //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                    //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                    Thread clearArrowThread = new Thread(ClearRemnants.ClearArrowsOnLeftWall);

                    //repairLeftWallThread.Start();
                    clearArrowThread.Start();
                }

            }
        }
    }
}
