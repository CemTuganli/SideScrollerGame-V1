﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    internal class JumpAnim
    {
        public void Jump()
        {
            bool landing = false;
            while (!landing)
            {
                //nereye ve ne kadarlık alana lock koyduğuna dikkat etyoksa oyun gereksiz kasar
                lock (Console.Out)
                {
                    // Erase the previous position of the player
                    Console.SetCursorPosition(PlayerCharacter.playerPosX, PlayerCharacter.playerPosY);
                    Console.Write(' ');

                    // Move the player to the new position
                    Console.SetCursorPosition(PlayerCharacter.playerPosX, --PlayerCharacter.playerPosY);
                    Console.Write('0');
                }

                Thread.Sleep(100);
                if (PlayerCharacter.playerPosY == 9)
                {
                    while (!landing)
                    {
                        lock (Console.Out)
                        {
                            // Erase the previous position of the player
                            Console.SetCursorPosition(PlayerCharacter.playerPosX, PlayerCharacter.playerPosY);
                            Console.Write(' ');

                            // Move the player to the new position
                            Console.SetCursorPosition(PlayerCharacter.playerPosX, ++PlayerCharacter.playerPosY);
                            Console.Write('0');
                        }
                        Thread.Sleep(100);
                        if (PlayerCharacter.playerPosY == 18)
                        {
                            landing = true;
                        }
                    }
                }
            }
        }

    }
}
