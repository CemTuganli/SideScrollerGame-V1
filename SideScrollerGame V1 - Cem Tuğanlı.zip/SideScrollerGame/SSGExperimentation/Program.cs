﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SSGExperimentation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int c = 2;
            Write.WriteALot(c);
            Observe.Wow();
            Thread hey = new Thread(() => Write.WriteALot(c));
            hey.Start();
            Console.ReadLine();
        }

    }
    public class Observe
    {
        public static void Wow()
        {
            int b=2;
            Write.WriteALot(b);
            Thread hey = new Thread(()=> Write.WriteALot(b));
            hey.Start();
        }
    }
    public class Write
    {
        public int a = 5;
        public static void WriteALot(int a)
        {
            Console.Write(a);
        }
    }
}
