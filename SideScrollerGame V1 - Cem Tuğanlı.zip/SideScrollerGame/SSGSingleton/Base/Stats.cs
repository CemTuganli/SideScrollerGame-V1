﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    internal class Stats
    {
        private static byte health = 3;
        private static byte score = 0;

        public static byte Health { get => health; set => health = value; }
        public static byte Score { get => score; set => score = value; }
        public static void DamageWarningHealthDecrease()
        {
            Stats st = new Stats();
            if (Health <= 0)
            {
                lock (Console.Out)
                {
                    Health = 0;
                    Stats.GameoverRestartExit();
                }
            }
            else if ((Arrows.ArrowPosX1 == PlayerCharacter.playerPosX && Arrows.ArrowPosY1 == PlayerCharacter.playerPosY) || (Arrows.ArrowPosX1 + 1 == PlayerCharacter.playerPosX && Arrows.ArrowPosY1 == PlayerCharacter.playerPosY) || (Arrows.ArrowPosX1 + 2 == PlayerCharacter.playerPosX && Arrows.ArrowPosY1 == PlayerCharacter.playerPosY) || (Arrows.ArrowPosX1 + 3 == PlayerCharacter.playerPosX && Arrows.ArrowPosY1 == PlayerCharacter.playerPosY))
            {
                lock (Console.Out)
                {
                    --Health;
                    DrawStatsScore(Health, Score);
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);

                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                    return;
                }
            }
            else if ((Arrows.ArrowPosX2 == PlayerCharacter.playerPosX && Arrows.ArrowPosY2 == PlayerCharacter.playerPosY) || (Arrows.ArrowPosX2 + 1 == PlayerCharacter.playerPosX && Arrows.ArrowPosY2 == PlayerCharacter.playerPosY) || (Arrows.ArrowPosX2 + 2 == PlayerCharacter.playerPosX && Arrows.ArrowPosY2 == PlayerCharacter.playerPosY) || (Arrows.ArrowPosX2 + 3 == PlayerCharacter.playerPosX && Arrows.ArrowPosY2 == PlayerCharacter.playerPosY))
            {
                lock (Console.Out)
                {
                    --Stats.Health;
                    DrawStatsScore(Stats.Health, Stats.Score);
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);


                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                    return;
                }
            }
        }
        public static void RestorePlayerGameValues()
        {
            Inputs inp = new Inputs();
            Stats.Health = 3;
            Stats.Score = 0;
            Inputs.GameOverRestartExit = false;
        }
        public static void GameoverRestartExit()
        {
            Inputs inp = new Inputs();
            lock (Console.Out)
            {
                //while döngüsü sayesinde her input denemesinde okların vs. 1 adım hareket etmesi sorununu çözdüm
                bool ask = true;
                while (ask)
                {
                    //Bu booleanı başa alarak input exit restart olayını 1 kez 2 input girişi denemesine düşürdüm. 
                    Inputs.GameOverRestartExit = true;

                    Console.CursorVisible = false;
                    Console.SetCursorPosition(46, 10);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("GAME OVER!!!!");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.SetCursorPosition(28, 12);
                    Console.WriteLine("Do you want to restart the game or exit to main menu?");
                    Console.SetCursorPosition(40, 14);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("    Restart: R   Exit: E");
                    Console.ForegroundColor = ConsoleColor.White;

                    ConsoleKeyInfo keyinfo = Console.ReadKey(true);
                    if (keyinfo.KeyChar == 'r' || keyinfo.KeyChar == 'R')
                    {
                        Stats.RestorePlayerGameValues();
                        Console.Clear();
                        ask = false;
                    }
                    else if (keyinfo.KeyChar == 'e' || keyinfo.KeyChar == 'E')
                    {
                        RestorePlayerGameValues();
                        Console.Clear();
                        ask = false;
                    }
                    else
                    {
                        RestartExitWrongKeyWarning();
                    }
                }
            }
        }
        public static void RestartExitWrongKeyWarning()
        {
            lock (Console.Out)
            {
                byte count = 0;
                Console.Beep();
                while (count <= 5)
                {
                    Console.SetCursorPosition(40, 16);
                    System.Threading.Thread.Sleep(150);
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.Write("Please Enter A Valid Key!");
                    System.Threading.Thread.Sleep(150);
                    Console.SetCursorPosition(40, 16);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("Please Enter A Valid Key!");
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }
                Console.SetCursorPosition(40, 16);
                Console.Write("                         ");
                Console.ForegroundColor = ConsoleColor.White;

            }
        }
        public static void WarningMessage()
        {

            byte count = 0;
            Console.Beep();
            while (count <= 5)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }

            }
            lock (Console.Out)
            {
                Console.SetCursorPosition(5, 1);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("                      ");
            }
        }
        public static void FlickeringHealth()
        {
            Stats st = new Stats();
            Console.ForegroundColor = ConsoleColor.Gray;
            byte count1 = 0;
            while (count1 <= 4)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Health : {Stats.Health}  ");
                    Thread.Sleep(50);
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write($"Health : {Stats.Health}  ");
                    Thread.Sleep(50);
                }
                ++count1;

            }
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {Stats.Health}  ");
                Console.Write($"Score : {Stats.Score}");
            }
        }
        public static void DrawStatsScore(int health, int score)
        {
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {health}  ");
                Console.Write($"Score : {score}");
            }
        }

    }
}
