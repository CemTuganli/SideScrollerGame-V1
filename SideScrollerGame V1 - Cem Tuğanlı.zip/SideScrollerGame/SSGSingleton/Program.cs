﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;


namespace SideScrollerGame
{
    internal class Program
    {
        //tüm whileları lock içerine alınan iki adet thread çalıştırılırsa o threadler aynı anda değil birinin diğerinin tüm döngüsünün tamamlamasını beklemesiyle geçer, yani eş zamanlı çalışmazlar!
        //değişkenlere globaldan ulaşmak bilgisayar için daha uzun sürüyor
        /*Semaphore da bozuk (slim olmayan)
        2 ok için Lock kullandıktan sonra semaphoreslim'e gerek yok bu örnekte !!!!!!!!!!!!!!!!!!!!  !!!!!!!!!
        semaphoreslim() lock'tan daha kötü, lock en azından 2 ok için işe yarıyor, semapohreslim 2 ok için bile bozuk
        semaphoreslim(1,1) lock ile aynı, semaphoreslim(2) bozuk, semaphoreslim(2,2) de bozuk
        only 2 threads can access to the same thread at the same time, semaphoreslim is a lighter alternative to semaphore
        lock ve semaphore birlikte kullanılınca da olmuyor
        ReaderWriterLockSlim lock ile aynı sonucu veriyor
        ManuelResetEvent de olmuyor
        while gameloop + Console.Clear olmuyor*/
        #region Fields


        #endregion
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Console.Clear();
            GameWindowMap.DrawGameWindow();
            GameWindowMap.DrawFloor();
            Stats.DrawStatsScore(Stats.Health, Stats.Score);
            PlayerCharacter.DrawPlayer();

            Gallons.CreateGallons();

            //10 adet gallondan birkaçı hatalı olarak hep saha dışına tepeye çiziliyor onları silmek için.
            Gallons.DeleteFalsePlacedGallons();

            Thread rndMoveArrowTHREAD1 = new Thread(Arrows.MoveArrows1);

            Thread rndMoveArrowTHREAD2 = new Thread(Arrows.MoveArrows2);

            Thread rndMoveArrowTHREAD3 = new Thread(Arrows.MoveArrows3);

            Thread handleinputThread = new Thread(Inputs.HandleInput);

            Thread rndLocationArrowGenTHREAD1 = new Thread(Arrows.RandomLocationArrowGenerator1);

            Thread rndLocationArrowGenTHREAD2 = new Thread(Arrows.RandomLocationArrowGenerator2);

            Thread rndLocationArrowGenTHREAD3 = new Thread(Arrows.RandomLocationArrowGenerator3);

            rndLocationArrowGenTHREAD1.Start();
            rndLocationArrowGenTHREAD2.Start();
            rndLocationArrowGenTHREAD3.Start();
            rndMoveArrowTHREAD3.Start();
            rndMoveArrowTHREAD2.Start();
            rndMoveArrowTHREAD1.Start();
            handleinputThread.Start();


        }


    }
}
