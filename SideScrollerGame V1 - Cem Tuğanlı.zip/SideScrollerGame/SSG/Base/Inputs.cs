﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    internal class Inputs
    {
        private bool gameOverRestartExit = false;

        public bool GameOverRestartExit { get => gameOverRestartExit; set => gameOverRestartExit = value; }

        public void HandleInput()
        {
            Gallons gl = new Gallons();
            FireBullets fb = new FireBullets();
            JumpAnim j = new JumpAnim();
            //while parantezinde gameOverRestartExit sistemini kurmasaydım input için 2 adet key tıklaması istenecekti çünkü hem while içersindeki ReadKey(true) hem de GameoverRestartExit() içersindeki ReadKey() input isteyecekti ama yine de 2 kez çift tıkladıktan sonra ancak 1 kez input algılayabiliyor
            while (GameOverRestartExit == false)
            {

                ConsoleKeyInfo keyInfo = Console.ReadKey(true);
                if (keyInfo.Key == ConsoleKey.Spacebar)
                {
                    //Delete remnant A character on screen when reset position to playerPosY=0
                    Thread jumpThread = new Thread(j.Jump);
                    jumpThread.Start();
                }
                else if (keyInfo.Key == ConsoleKey.F)
                {
                    // Fire a projectile horizontally
                    Thread projectileThread = new Thread(() => fb.Fire(gl.XY1));
                    projectileThread.Start();
                }
                else if ((keyInfo.Key == ConsoleKey.A) || (keyInfo.Key == ConsoleKey.D))
                {
                    Thread movePlayerThread = new Thread(() => PlayerCharacter.MovePlayer(keyInfo.Key));
                    movePlayerThread.Start();
                }
            }
        }
    }
}
