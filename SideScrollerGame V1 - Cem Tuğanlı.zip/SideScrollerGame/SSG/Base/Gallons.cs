﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Gallons
    {

        private readonly Random rndG = new Random();

        public byte[,] xY = new byte[5, 2];

        public static byte[,] XY { get => xY; set => xY = value; }

        public void CreateGallons()
        {
            byte x;
            byte y;
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < 5; i++)
                {
                    if (j == 0)
                    {
                        lock (Console.Out)
                        {
                            x = Convert.ToByte(rndG.Next(17, 89));
                            XY1[i, 0] = x;
                        }
                    }

                    else if (j == 1)
                    {
                        lock (Console.Out)
                        {
                            y = Convert.ToByte(rndG.Next(10, 19));
                            XY1[i, 1] = y;
                        }
                    }
                }
                for (int i = 0; i < XY1.GetLength(0); i++)
                {
                    lock (Console.Out)
                    {
                        Console.SetCursorPosition(XY1[i, 0], XY1[i, 1]);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write("o");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
            }
        }
        public void RefreshGallonsHitByArrows(byte[,] XY)
        {
            
            Stats st = new Stats();
            Arrows ar = new Arrows();

            for (int i = 0; i < XY.GetLength(0); i++)
            {
                if (PlayerCharacter.playerPosX == XY[i, 0] && PlayerCharacter.playerPosY == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        ++st.Score;
                        st.DrawStatsScore(st.Health, st.Score);
                        XY[i, 0] = 0;
                        return;
                    }
                }
                else if (ar.ArrowPosX2 + 8 == XY[i, 0] && ar.ArrowPosY2 == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                        return;
                    }
                }
                else if (ar.ArrowPosX1 + 8 == XY[i, 0] && ar.ArrowPosY1 == XY[i, 1])
                {
                    lock (Console.Out)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                        return;
                    }
                }

            }
        }
        public void RefreshGallonsHitByFireBullets(byte[,] XY, int i)
        {
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                Console.Write("o");
                Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void DeleteFalsePlacedGallons()
        {
            Console.SetCursorPosition(0, 0);
            string deletefalseplacedGallons = new string(' ', 100);
            Console.Write(deletefalseplacedGallons);
        }
    }
}
