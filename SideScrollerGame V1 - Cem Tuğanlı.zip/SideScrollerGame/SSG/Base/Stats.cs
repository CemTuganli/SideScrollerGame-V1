﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    internal class Stats
    {
        private byte health = 3;
        private byte score = 0;

        public byte Health { get => health; set => health = value; }
        public byte Score { get => score; set => score = value; }
        public void DamageWarningHealthDecrease()
        {
            Arrows ar = new Arrows();
            Stats st = new Stats();
            if (Health <= 0)
            {
                lock (Console.Out)
                {
                    Health = 0;
                    GameoverRestartExit();
                }
            }
            else if ((ar.ArrowPosX1 == PlayerCharacter.playerPosX && ar.ArrowPosY1 == PlayerCharacter.playerPosY) || (ar.ArrowPosX1 + 1 == PlayerCharacter.playerPosX && ar.ArrowPosY1 == PlayerCharacter.playerPosY) || (ar.ArrowPosX1 + 2 == PlayerCharacter.playerPosX && ar.ArrowPosY1 == PlayerCharacter.playerPosY) || (ar.ArrowPosX1 + 3 == PlayerCharacter.playerPosX && ar.ArrowPosY1 == PlayerCharacter.playerPosY))
            {
                lock (Console.Out)
                {
                    --Health;
                    DrawStatsScore(Health, Score);
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);


                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                    return;
                }
            }
            else if ((ar.ArrowPosX2 == PlayerCharacter.playerPosX && ar.ArrowPosY2 == PlayerCharacter.playerPosY) || (ar.ArrowPosX2 + 1 == PlayerCharacter.playerPosX && ar.ArrowPosY2 == PlayerCharacter.playerPosY) || (ar.ArrowPosX2 + 2 == PlayerCharacter.playerPosX && ar.ArrowPosY2 == PlayerCharacter.playerPosY) || (ar.ArrowPosX2 + 3 == PlayerCharacter.playerPosX && ar.ArrowPosY2 == PlayerCharacter.playerPosY))
            {
                lock (Console.Out)
                {
                    --st.Health;
                    DrawStatsScore(st.Health, st.Score);
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);


                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                    return;
                }
            }
        }
        public void RestorePlayerGameValues()
        {
            Stats st = new Stats();
            Inputs inp = new Inputs();
            st.Health = 3;
            st.Score = 0;
            inp.GameOverRestartExit = false;
        }
        public void GameoverRestartExit()
        {
            Inputs inp = new Inputs();
            lock (Console.Out)
            {
                //while döngüsü sayesinde her input denemesinde okların vs. 1 adım hareket etmesi sorununu çözdüm
                bool ask = true;
                while (ask)
                {
                    //Bu booleanı başa alarak input exit restart olayını 1 kez 2 input girişi denemesine düşürdüm. 
                    inp.GameOverRestartExit = true;

                    Console.CursorVisible = false;
                    Console.SetCursorPosition(46, 10);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("GAME OVER!!!!");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.SetCursorPosition(28, 12);
                    Console.WriteLine("Do you want to restart the game or exit to main menu?");
                    Console.SetCursorPosition(40, 14);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("    Restart: R   Exit: E");
                    Console.ForegroundColor = ConsoleColor.White;

                    ConsoleKeyInfo keyinfo = Console.ReadKey(true);
                    if (keyinfo.KeyChar == 'r' || keyinfo.KeyChar == 'R')
                    {
                        RestorePlayerGameValues();
                        Console.Clear();
                        ask = false;
                    }
                    else if (keyinfo.KeyChar == 'e' || keyinfo.KeyChar == 'E')
                    {
                        RestorePlayerGameValues();
                        Console.Clear();
                        ask = false;
                    }
                    else
                    {
                        RestartExitWrongKeyWarning();
                    }
                }
            }
        }
        public void RestartExitWrongKeyWarning()
        {
            lock (Console.Out)
            {
                byte count = 0;
                Console.Beep();
                while (count <= 5)
                {
                    Console.SetCursorPosition(40, 16);
                    System.Threading.Thread.Sleep(150);
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.Write("Please Enter A Valid Key!");
                    System.Threading.Thread.Sleep(150);
                    Console.SetCursorPosition(40, 16);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("Please Enter A Valid Key!");
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }
                Console.SetCursorPosition(40, 16);
                Console.Write("                         ");
                Console.ForegroundColor = ConsoleColor.White;

            }
        }
        public void WarningMessage()
        {

            byte count = 0;
            Console.Beep();
            while (count <= 5)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }

            }
            lock (Console.Out)
            {
                Console.SetCursorPosition(5, 1);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("                      ");
            }
        }
        public void FlickeringHealth()
        {
            Stats st = new Stats();
            Console.ForegroundColor = ConsoleColor.Gray;
            byte count1 = 0;
            while (count1 <= 4)
            {
                lock (Console.Out)
                {
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Health : {st.Health}  ");
                    Thread.Sleep(50);
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write($"Health : {st.Health}  ");
                    Thread.Sleep(50);
                }
                ++count1;

            }
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {st.Health}  ");
                Console.Write($"Score : {st.Score}");
            }
        }
        public void DrawStatsScore(int health, int score)
        {
            lock (Console.Out)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {health}  ");
                Console.Write($"Score : {score}");
            }
        }

    }
}
