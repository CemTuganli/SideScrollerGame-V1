﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class PlayerCharacter
    {
        public static int playerPosX = 18;
        public static int playerPosY = 18;
        public static void DrawPlayer()
        {
            lock (Console.Out)
            {
                Console.SetCursorPosition(playerPosX, playerPosY);
                Console.Write("0");
            }
        }

        public static void MovePlayer(ConsoleKey keyInfo)
        {
            if (keyInfo == ConsoleKey.A)
            {
                lock (Console.Out)
                {
                    if (playerPosX >= 14)
                    {
                        Console.SetCursorPosition(--playerPosX, playerPosY);
                        Console.Write('0');
                        Console.Write(' ');
                    }
                    else
                    {
                        return;
                    }
                }
            }
            else if (keyInfo == ConsoleKey.D)
            {
                lock (Console.Out)
                {
                    if (playerPosX <= 94)
                    {
                        Console.SetCursorPosition(playerPosX, playerPosY);
                        Console.Write(' ');
                        Console.SetCursorPosition(++playerPosX, playerPosY);
                        Console.Write('0');
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }
    }
}
