﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;


namespace SideScrollerGame
{
    internal class Program
    {
        //tüm whileları lock içerine alınan iki adet thread çalıştırılırsa o threadler aynı anda değil birinin diğerinin tüm döngüsünün tamamlamasını beklemesiyle geçer, yani eş zamanlı çalışmazlar!
        //değişkenlere globaldan ulaşmak bilgisayar için daha uzun sürüyor
        /*Semaphore da bozuk (slim olmayan)
        2 ok için Lock kullandıktan sonra semaphoreslim'e gerek yok bu örnekte !!!!!!!!!!!!!!!!!!!!  !!!!!!!!!
        semaphoreslim() lock'tan daha kötü, lock en azından 2 ok için işe yarıyor, semapohreslim 2 ok için bile bozuk
        semaphoreslim(1,1) lock ile aynı, semaphoreslim(2) bozuk, semaphoreslim(2,2) de bozuk
        only 2 threads can access to the same thread at the same time, semaphoreslim is a lighter alternative to semaphore
        lock ve semaphore birlikte kullanılınca da olmuyor
        ReaderWriterLockSlim lock ile aynı sonucu veriyor
        ManuelResetEvent de olmuyor
        while gameloop + Console.Clear olmuyor*/
        #region Fields


        #endregion
        static void Main(string[] args)
        {
            GameWindowMap gwm = new GameWindowMap();    
            PlayerCharacter pc = new PlayerCharacter();
            Stats st = new Stats();
            Gallons gl = new Gallons();
            Arrows ar = new Arrows();
            Inputs inp = new Inputs();

            Console.CursorVisible = false;
            Console.Clear();
            gwm.DrawGameWindow();
            gwm.DrawFloor();
            st.DrawStatsScore(st.Health, st.Score);

            gl.CreateGallons();

            //10 adet gallondan birkaçı hatalı olarak hep saha dışına tepeye çiziliyor onları silmek için.
            gl.DeleteFalsePlacedGallons();

            Thread rndMoveArrowTHREAD1 = new Thread(ar.MoveArrows1);

            Thread rndMoveArrowTHREAD2 = new Thread(ar.MoveArrows2);

            Thread handleinputThread = new Thread(inp.HandleInput);

            Thread rndLocationArrowGenTHREAD1 = new Thread(ar.RandomLocationArrowGenerator1);

            Thread rndLocationArrowGenTHREAD2 = new Thread(ar.RandomLocationArrowGenerator2);

            rndLocationArrowGenTHREAD1.Start();
            rndLocationArrowGenTHREAD2.Start();
            rndMoveArrowTHREAD2.Start();
            rndMoveArrowTHREAD1.Start();
            handleinputThread.Start();


        }
        

    }
}
