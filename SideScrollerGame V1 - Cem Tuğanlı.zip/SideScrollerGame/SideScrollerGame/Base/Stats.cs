﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Stats
    {
        static readonly CommonGround cg = CommonGround.Cg;

        static readonly Program pr = Program.Pr;
        static readonly Inputs inp = Inputs.Inp;
        static readonly Arrows arr = Arrows.Arr;
        static readonly PlayerCharacter PC = PlayerCharacter.PC;

        private static Lazy<Stats> _stats;
        public static Stats St
        {
            get
            {
                if (_stats == null)
                {
                    _stats = new Lazy<Stats>(() => new Stats());
                }
                return _stats.Value;
            }
        }
        private Stats()
        {

        }

        private byte health = 3;
        private byte score = 0;

        public byte Health { get => health; set => health = value; }
        public byte Score { get => score; set => score = value; }
        public void DamageWarningHealthDecrease()
        {
            if (Health <= 0 || Health > 230)
            {
                lock (cg.LockObject)
                {
                    if (Health <= 0 || Health > 230)
                    {
                        Health = 0;
                        DrawStatsScore();
                        GameoverRestartExit();
                    }
                }

            }
            else if ((arr.ArrowPosX1 == PC.playerPosX && arr.ArrowPosY1 == PC.playerPosY) || (arr.ArrowPosX1 + 1 == PC.playerPosX && arr.ArrowPosY1 == PC.playerPosY) || (arr.ArrowPosX1 + 2 == PC.playerPosX && arr.ArrowPosY1 == PC.playerPosY) || (arr.ArrowPosX1 + 3 == PC.playerPosX && arr.ArrowPosY1 == PC.playerPosY))
            {
                lock (cg.LockObject)
                {
                    lock (cg.LockObject)
                    {
                        if (Health <= 0 || Health > 230)
                        {
                            Health = 0;
                            DrawStatsScore();
                            GameoverRestartExit();
                        }
                        else
                        {
                            --Health;
                            DrawStatsScore();
                        }
                    }
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);

                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                }
            }
            else if ((arr.ArrowPosX2 == PC.playerPosX && arr.ArrowPosY2 == PC.playerPosY) || (arr.ArrowPosX2 + 1 == PC.playerPosX && arr.ArrowPosY2 == PC.playerPosY) || (arr.ArrowPosX2 + 2 == PC.playerPosX && arr.ArrowPosY2 == PC.playerPosY) || (arr.ArrowPosX2 + 3 == PC.playerPosX && arr.ArrowPosY2 == PC.playerPosY))
            {
                lock (cg.LockObject)
                {
                    if (Health < 0 || Health > 230)
                    {
                        Health = 0;
                        DrawStatsScore();
                        GameoverRestartExit();
                    }
                    else
                    {
                        --Health;
                        DrawStatsScore();
                    }
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);


                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                }
            }
            else if ((arr.ArrowPosX3 == PC.playerPosX && arr.ArrowPosY3 == PC.playerPosY) || (arr.ArrowPosX3 + 1 == PC.playerPosX && arr.ArrowPosY3 == PC.playerPosY) || (arr.ArrowPosX3 + 2 == PC.playerPosX && arr.ArrowPosY3 == PC.playerPosY) || (arr.ArrowPosX3 + 3 == PC.playerPosX && arr.ArrowPosY3 == PC.playerPosY))
            {
                lock (cg.LockObject)
                {
                    if (Health < 0 || Health > 230)
                    {
                        Health = 0;
                        DrawStatsScore();
                        GameoverRestartExit();
                    }
                    else
                    {
                        --Health;
                        DrawStatsScore();

                    }
                    Thread warningThread = new Thread(WarningMessage);
                    Thread flickeringHealthThread = new Thread(FlickeringHealth);


                    /*Thread warningCharacter = new Thread(() => WarningCharacter(playerPosX, playerPosY));
                    warningCharacter.Start();*/
                    warningThread.Start();
                    flickeringHealthThread.Start();
                }
            }
        }
        public void RestorePlayerGameValues()
        {
            Health = 3;
            Score = 0;
            inp.GameOverRestartExit = false;
        }

        public char a = '1';
        public void GameoverRestartExit()
        {
            
            lock (cg.LockObject)
            {
                Health = 0;
                //while döngüsü sayesinde her input denemesinde okların vs. 1 adım hareket etmesi sorununu çözdüm
                bool ask = true;
                while (ask)
                {
                    //Bu booleanı başa alarak input exit restart olayını 1 kez 2 input girişi denemesine düşürdüm. 
                    inp.GameOverRestartExit = true;

                    Console.CursorVisible = false;
                    Console.SetCursorPosition(46, 10);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("GAME OVER!!!!");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.SetCursorPosition(28, 12);
                    Console.WriteLine("Do you want to restart the game or exit to main menu?");
                    Console.SetCursorPosition(25, 14);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("           Restart: R   Exit: E   Main Menu: M");
                    Console.ForegroundColor = ConsoleColor.White;

                    ConsoleKeyInfo keyinfo = Console.ReadKey(true);
                    if (keyinfo.Key == ConsoleKey.R)
                    {
                        lock (cg.LockObject)
                        {
                            Console.Clear();
                            //Bunların 3'ünü bir tread yapmak Healthı 256 nın altına düşürüyor ve oyunun görüntüsünün bozuk gelmesine silik gelmesine sabep oluyor
                            St.RestorePlayerGameValues();
                            PC.ResetPlayerPosition();
                            pr.GameChoice(a);
                            ask = false;

                        }
                    }
                    else if (keyinfo.Key == ConsoleKey.E)
                    {
                        Environment.Exit(0);
                    }
                    else if (keyinfo.Key == ConsoleKey.M)
                    {
                        lock (cg.LockObject)
                        {
                            Console.Clear();
                            pr.ChooseScreen();
                            St.RestorePlayerGameValues();
                            PC.ResetPlayerPosition();
                            ask = false;
                        }
                    }
                }
            }
        }
        public void RestartExitWrongKeyWarning()
        {
            lock (cg.LockObject)
            {
                byte count = 0;
                Console.Beep();
                while (count <= 5)
                {
                    Console.SetCursorPosition(40, 16);
                    System.Threading.Thread.Sleep(150);
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.Write("Please Enter A Valid Key!");
                    System.Threading.Thread.Sleep(150);
                    Console.SetCursorPosition(40, 16);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("Please Enter A Valid Key!");
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }
                Console.SetCursorPosition(40, 16);
                Console.Write("                         ");
                Console.ForegroundColor = ConsoleColor.White;

            }
        }
        public void WarningMessage()
        {

            byte count = 0;
            Console.Beep();
            while (count <= 5)
            {
                lock (cg.LockObject)
                {
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    Console.SetCursorPosition(5, 1);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write("You've taken a damage!");
                    System.Threading.Thread.Sleep(50);
                    ++count;
                    if (count == 5)
                    {
                        break;
                    }
                }

            }
            lock (cg.LockObject)
            {
                Console.SetCursorPosition(5, 1);
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("                      ");
            }
        }
        public void FlickeringHealth()
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            byte count1 = 0;
            while (count1 <= 4)
            {
                lock (cg.LockObject)
                {
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Health : {health}  ");
                    Thread.Sleep(50);
                    Console.SetCursorPosition(78, 4);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write($"Health : {health}  ");
                    Thread.Sleep(50);
                }
                ++count1;

            }
            lock (cg.LockObject)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {health}  ");
                Console.Write($"Score : {score}");
            }
        }
        public void DrawStatsScore()
        {
            lock (cg.LockObject)
            {
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.SetCursorPosition(78, 4);
                Console.Write($"Health : {health}  ");
                Console.Write($"Score : {score}");
            }
        }

    }
}
