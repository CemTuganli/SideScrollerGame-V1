﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public static class Gallons
    {
        static readonly CommonGround cg = CommonGround.Cg;

        static readonly Stats st = Stats.St;
        static readonly PlayerCharacter pc = PlayerCharacter.PC;
        static readonly Arrows arr = Arrows.Arr;

        private static readonly Random rndG = new Random();

        public static byte[,] XY = new byte[15, 2];

        public static byte[,] XY1 { get => XY; set => XY = value; }

        public static void CreateGallons()
        {
            byte x;
            byte y;
            for (int j = 0; j < 2; j++)
            {
                for (int i = 0; i < 15; i++)
                {
                    if (j == 0)
                    {
                        lock (cg.LockObject)
                        {
                            x = Convert.ToByte(rndG.Next(17, 89));
                            Gallons.XY1[i, 0] = x;
                        }
                    }

                    else if (j == 1)
                    {
                        lock (cg.LockObject)
                        {
                            y = Convert.ToByte(rndG.Next(9, 18));
                            Gallons.XY1[i, 1] = y;
                        }
                    }
                }
                for (int i = 0; i < Gallons.XY1.GetLength(0); i++)
                {
                    lock (cg.LockObject)
                    {
                        Console.SetCursorPosition(Gallons.XY1[i, 0], Gallons.XY1[i, 1]);
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write("o");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
            }
        }
        public static void RefreshGallonsHitByArrows(byte[,] XY)
        {

            for (int i = 0; i < XY.GetLength(0); i++)
            {
                if (pc.playerPosX == XY[i, 0] && pc.playerPosY == XY[i, 1])
                {
                    lock (cg.LockObject)
                    {
                        ++st.Score;
                        st.DrawStatsScore();
                        XY[i, 0] = 0;
                    }
                }
                else if (arr.ArrowPosX2 + 8 == XY[i, 0] && arr.ArrowPosY2 == XY[i, 1])
                {
                    lock (cg.LockObject)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
                else if (arr.ArrowPosX1 + 8 == XY[i, 0] && arr.ArrowPosY1 == XY[i, 1])
                {
                    lock (cg.LockObject)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
                else if (arr.ArrowPosX3 + 8 == XY[i, 0] && arr.ArrowPosY3 == XY[i, 1])
                {
                    lock (cg.LockObject)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                        Console.Write("o");
                        Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }

            }
        }
        public static void RefreshGallonsHitByFireBullets(byte[,] XY, int i)
        {
            lock (cg.LockObject)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.SetCursorPosition(XY[i, 0], XY[i, 1]);
                Console.Write("o");
                Console.SetCursorPosition(XY[i, 0] - 1, XY[i, 1]);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public static void DeleteFalsePlacedGallons()
        {
            Console.SetCursorPosition(0, 0);
            string deletefalseplacedGallons = new string(' ', 100);
            Console.Write(deletefalseplacedGallons);
        }

    }
}
