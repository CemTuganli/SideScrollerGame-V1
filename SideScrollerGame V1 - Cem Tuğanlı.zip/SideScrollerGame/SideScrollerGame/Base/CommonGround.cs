﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class CommonGround
    {
        private readonly static CommonGround _cg = new CommonGround();
        public static CommonGround Cg
        {
            get { return _cg; }
        }

        public object LockObject = new object();

        private CommonGround() 
        {
        
        }
    }
}
