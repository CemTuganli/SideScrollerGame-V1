﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class Arrows
    {
        static readonly CommonGround cg = CommonGround.Cg;

        static readonly Program pr = Program.Pr;

        static readonly Stats st = Stats.St;

        private static Lazy<Arrows> _arr;
        public static Arrows Arr
        {
            get
            {
                //create a singleton, if not created already
                if (_arr == null)
                {
                    //instancing happens
                    _arr = new Lazy<Arrows>(() => new Arrows());
                }
                return _arr.Value;
            }
        }
        private Arrows()
        {

        }

        private readonly static Random rnd = new Random(DateTime.UtcNow.Millisecond);

        private int arrowPosX1;
        private int arrowPosY1;
        private int arrowPosX2;
        private int arrowPosY2;
        private int arrowPosX3;
        private int arrowPosY3;

        public int ArrowPosX1 { get => arrowPosX1; set => arrowPosX1 = value; }
        public int ArrowPosY1 { get => arrowPosY1; set => arrowPosY1 = value; }
        public int ArrowPosX2 { get => arrowPosX2; set => arrowPosX2 = value; }
        public int ArrowPosY2 { get => arrowPosY2; set => arrowPosY2 = value; }
        public int ArrowPosX3 { get => arrowPosX3; set => arrowPosX3 = value; }
        public int ArrowPosY3 { get => arrowPosY3; set => arrowPosY3 = value; }

        public void RandomLocationArrowGenerator1()
        {
            //Okların nereye kadar ilerleyeceklerini bu döngülerdeki süreler Sleep süreleri belirliyor
            //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
            Arr.ArrowPosX1 = rnd.Next(80, 85);
            Arr.ArrowPosY1 = rnd.Next(9, 12);


        }

        /*
        private void RefreshBeforeArrowDisappear1()
        {
            lock (cg.LockObject)
            {
                for (int i = 0; i < Gallons.XY.GetLength(0); i++)
                {
                    if ((arr.arrowPosX1 == Gallons.XY[i, 0] || arr.arrowPosX1 + 1 == Gallons.XY[i, 0] || arr.arrowPosX1 + 2 == Gallons.XY[i, 0] || arr.arrowPosX1 + 3 == Gallons.XY[i, 0]) && arr.arrowPosY1 == Gallons.XY[i, 1])
                    {
                        Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
                    }
                }
            }
        }*/

        public void RandomLocationArrowGenerator2()
        {
            //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
            Arr.ArrowPosX2 = rnd.Next(80, 85);
            Arr.ArrowPosY2 = rnd.Next(15, 19);

            lock (cg.LockObject)
            {
                Console.SetCursorPosition(Arr.ArrowPosX2 - 3, Arr.ArrowPosY2);
                Console.Write("     ");

            }
        }

        /*//private void RefreshBeforeArrowDisappear2()
        //{
        //    lock (cg.LockObject)
        //    {
        //        for (int i = 0; i < Gallons.XY.GetLength(0); i++)
        //        {
        //            if ((arr.arrowPosX2 == Gallons.XY[i, 0] || arr.arrowPosX2 + 1 == Gallons.XY[i, 0] || arr.arrowPosX2 + 2 == Gallons.XY[i, 0] || arr.arrowPosX2 + 3 == Gallons.XY[i, 0]) && arr.arrowPosY2 == Gallons.XY[i, 1])
        //            {
        //                Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
        //            }
        //        }
        //    }
        //}*/

        public void RandomLocationArrowGenerator3()
        {
            //bu kod bloğuna lock() koymak kodu bozuyor, sonsuz bekleme yaratıyor
            Arr.ArrowPosX3 = rnd.Next(80, 85);
            Arr.ArrowPosY3 = rnd.Next(12, 15);


            lock (cg.LockObject)
            {
                Console.SetCursorPosition(Arr.ArrowPosX3 - 3, Arr.ArrowPosY3);
                Console.Write("     ");

            }

            /*//lock (cg.LockObject)
            //{
            //    if ((ArrowPosX1 - 2 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 - 1 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 1 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 2 == ArrowPosX2 && ArrowPosY1 == ArrowPosY2))
            //    {
            //        arrowPosY1 += 1;
            //    }
            //    else if ((ArrowPosX1 - 2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 - 1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX1 + 2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2))
            //    {
            //        arrowPosY1 -= 1;
            //    }
            //    else if ((ArrowPosX2 - 2 == ArrowPosX3 && ArrowPosY2 == ArrowPosY3) || (ArrowPosX2 - 1 == ArrowPosX3 && ArrowPosY2 == ArrowPosY3) || (ArrowPosX2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX2 + 1 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2) || (ArrowPosX2 + 2 == ArrowPosX3 && ArrowPosY1 == ArrowPosY2))
            //    {
            //        arrowPosY2 -= 2;
            //    }
            //}*/
        }

        /*
        private void RefreshBeforeArrowDisappear3()
        {
            lock (cg.LockObject)
            {
                for (int i = 0; i < Gallons.XY.GetLength(0); i++)
                {
                    if ((arr.arrowPosX3 == Gallons.XY[i, 0] || arr.arrowPosX3 + 1 == Gallons.XY[i, 0] || arr.arrowPosX3 + 2 == Gallons.XY[i, 0] || arr.arrowPosX3 + 3 == Gallons.XY[i, 0]) && arr.arrowPosY3 == Gallons.XY[i, 1])
                    {
                        Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
                    }
                }
            }
        }*/

        public void MoveArrows1()
        {
            while (Arr.ArrowPosX1 > 7)
            {
                lock (cg.LockObject)
                {
                    if(!pr.isPaused)
                    { 
                        Console.SetCursorPosition(Arr.ArrowPosX1, Arr.ArrowPosY1);
                        Console.Write("  ");
                        Console.SetCursorPosition(Arr.ArrowPosX1 - 2, Arr.ArrowPosY1);
                        Console.Write("<--");
                    }
                }

                if (!pr.isPaused)
                {
                    --Arr.ArrowPosX1;
                    System.Threading.Thread.Sleep(15);
                    Thread DamageThread = new Thread(st.DamageWarningHealthDecrease);
                    System.Threading.Thread.Sleep(15);

                    Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
                    DamageThread.Start();
                    RefreshGallonsThread.Start();
                    lock (cg.LockObject)
                    {
                        if (Arr.ArrowPosX1 <= 11)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                        {
                            //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                            //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                            //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                            //repairLeftWallThread.Start();
                            Console.SetCursorPosition(Arr.ArrowPosX1 - 3, Arr.ArrowPosY1);
                            Console.Write("     ");
                            RandomLocationArrowGenerator1();
                        }

                    } 
                }

            }
        }
        public void MoveArrows2()
        {
            while (Arr.ArrowPosX2 > 7)
            {
                lock (cg.LockObject)
                {
                    if (!pr.isPaused)
                    {
                        Console.SetCursorPosition(Arr.ArrowPosX2, Arr.ArrowPosY2);
                        Console.Write("  ");
                        Console.SetCursorPosition(Arr.ArrowPosX2 - 2, Arr.ArrowPosY2);
                        Console.Write("<--");
                    }
                }

                if (!pr.isPaused)
                {
                    --Arr.ArrowPosX2;
                    Thread DamageThread = new Thread(st.DamageWarningHealthDecrease);
                    DamageThread.Start();
                    System.Threading.Thread.Sleep(18);

                    Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
                    RefreshGallonsThread.Start();
                    System.Threading.Thread.Sleep(18);
                    lock (cg.LockObject)
                    {
                        if (Arr.ArrowPosX2 <= 11)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                        {
                            //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                            //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                            //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                            //repairLeftWallThread.Start();
                            Console.SetCursorPosition(Arr.ArrowPosX2 - 3, Arr.ArrowPosY2);
                            Console.Write("     ");
                            RandomLocationArrowGenerator2();
                        }

                    } 
                }
            }
        }

        public void MoveArrows3()
        {

            while (Arr.ArrowPosX3 > 6)
            {
                lock (cg.LockObject)
                {
                    if (!pr.isPaused)
                    {
                        Console.SetCursorPosition(Arr.ArrowPosX3, Arr.ArrowPosY3);
                        Console.Write("  ");
                        Console.SetCursorPosition(Arr.ArrowPosX3 - 2, Arr.ArrowPosY3);
                        Console.Write("<--");
                    }
                }

                if (!pr.isPaused)// bu kısmı da ş içersine alınca oklar arkaplanda hareket etmeyi yani canımı azaltmayı ve gallonları kırpıştırmayı kesti
                {
                    --Arr.ArrowPosX3;
                    Thread DamageThread = new Thread(st.DamageWarningHealthDecrease);
                    DamageThread.Start();
                    System.Threading.Thread.Sleep(21);

                    Thread RefreshGallonsThread = new Thread(() => Gallons.RefreshGallonsHitByArrows(Gallons.XY1));
                    RefreshGallonsThread.Start();
                    System.Threading.Thread.Sleep(21);

                    lock (cg.LockObject)
                    {
                        if (Arr.ArrowPosX3 <= 11)//buranın değerinin ne olduğuna bakılmaksızın duvar bozuluyor, okların nerde silindiğinin duvar için önemi yok
                        {
                            //aşağıdaki kodları lock ile kilitlemek oyunu bozuyor
                            //wall reapair işlemini gamewindowda sağa almasaydık repair kullanacaktık ama ekranı bozuyor
                            //Thread repairLeftWallThread = new Thread(RepairLeftWall);
                            //repairLeftWallThread.Start();
                            Console.SetCursorPosition(Arr.ArrowPosX3 - 3, Arr.ArrowPosY3);
                            Console.Write("     ");
                            RandomLocationArrowGenerator3();
                        }

                    } 
                }

            }
        }
    }
}

