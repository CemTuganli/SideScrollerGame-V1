﻿using System;
using System.Threading;

namespace PauseResumeThreading
{
    internal class Program
    {
        static int a = 0;
        static int c = 0;
        static bool isRunning = true;

        static void Main(string[] args)
        {
            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);
                Thread threadCount = new Thread(Count);
                threadCount.Start();
                if (key.Key == ConsoleKey.P && c % 2 == 0)
                {
                    ++c;
                    isRunning = true;
                }
                else if (key.Key == ConsoleKey.P && c % 2 != 0)
                {
                    c = 0;
                    isRunning = false;
                }
            }
        }

        private static void Count()
        {
            while (isRunning)
            {
                lock (Console.Out)
                {
                    Console.Write(a++);
                    System.Threading.Thread.Sleep(500);
                }
            }
        }
    }
}
