﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class PlayerCharacter
    {
        static readonly CommonGround cg = CommonGround.Cg;

        static readonly Program pr = Program.Pr;
        private static Lazy<PlayerCharacter> _pc;
        public static PlayerCharacter PC
        {
            get
            {
                //create a singleton, if not created already
                if (_pc == null)
                {
                    //instancing happens
                    _pc = new Lazy<PlayerCharacter>(() => new PlayerCharacter());
                }
                return _pc.Value;
            }
        }

        private PlayerCharacter()
        {

        }

        public int playerPosX = 18;
        public int playerPosY = 18;
        public void ResetPlayerPosition()
        {
            playerPosX = 18;
            playerPosY = 18;
        }
        public void DrawPlayer()
        {
            lock (cg.LockObject)
            {
                Console.SetCursorPosition(PC.playerPosX, PC.playerPosY);
                Console.Write("0");
            }
        }

        public void MovePlayer(ConsoleKey keyInfo)
        {
            if (keyInfo == ConsoleKey.A)
            {
                lock (cg.LockObject)
                {
                    if (PC.playerPosX >= 14)
                    {
                        if (!pr.isPaused)
                        {
                            Console.SetCursorPosition(--PC.playerPosX, PC.playerPosY);
                            Console.Write('0');
                            Console.Write(' ');
                        }
                    }
                }
            }
            else if (keyInfo == ConsoleKey.D)
            {
                lock (cg.LockObject)
                {
                    if (PC.playerPosX <= 94)
                    {
                        if (!pr.isPaused)
                        {
                            Console.SetCursorPosition(PC.playerPosX, PC.playerPosY);
                            Console.Write(' ');
                            Console.SetCursorPosition(++PC.playerPosX, PC.playerPosY);
                            Console.Write('0');
                        }
                    }
                }
            }
        }

    }

}
