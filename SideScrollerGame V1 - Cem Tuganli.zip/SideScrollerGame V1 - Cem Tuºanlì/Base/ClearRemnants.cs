﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    internal class ClearRemnants
    {
        static readonly CommonGround cg = CommonGround.Cg;

        public static void ClearBulletsOnRightWall()
        {
            int timer = 0;
            byte count = 0;

            while (count < 2)
            {
                bool timeisup = false;
                while (!timeisup)
                {
                    timer++;

                    if (timer >= 10000000)
                    {
                        for (int i = 0; i < 10; i++)
                        {
                            lock (cg.LockObject)
                            {
                                Console.SetCursorPosition(100, 18 - i);
                                Console.Write(' ');
                            }
                            if (i == 8)
                            {
                                if (count == 2)
                                {
                                    timeisup = true;
                                }
                            }
                        }
                    }
                }
                count++;
            }

        }
        public static void ClearArrowsOnLeftWall()
        {
            int timer = 0;
            int count = 0;
            while (count < 5)
            {
                bool timeisup = false;
                while (!timeisup)
                {
                    ++timer;
                    if (timer >= 10000)
                    {
                        for (int j = 0; j < 10; j++)
                        {
                            for (int i = 0; i < 6; i++)
                            {
                                lock (cg.LockObject)
                                {
                                    //SetCursorPosition'daki x değerini 1 arttırdıkça duvarda yok olan dikeydeki karakter sayısı azalıyor 
                                    //okların duraklama locationları da ona göre belirlenmeli
                                    Console.SetCursorPosition(11 + i, 18 - j);
                                    Console.Write(' ');
                                }

                                if (count == 4)
                                {
                                    if (i == 4)
                                    {
                                        count = 5;
                                        timeisup = true;
                                    }
                                }
                            }
                        }
                    }
                }
                ++count;
            }

        }
    }
}
