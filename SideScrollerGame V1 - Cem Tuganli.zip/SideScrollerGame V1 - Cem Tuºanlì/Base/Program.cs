﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;


namespace SideScrollerGame
{
    internal class Program
    {
        //ÖNEMLİ NOT : GALLONLARI SINGLETON YERİNE STATİC CLASS YAPINCA ARROWLAR ONLARI SİLMEMEYE BAĞLADI GALLONLAR KENDİLERİNİ REFRESH EDEBİLDİLER
        #region Açıklamalar
        //tüm whileları lock içerine alınan iki adet thread çalıştırılırsa o threadler aynı anda değil birinin diğerinin tüm döngüsünün tamamlamasını beklemesiyle geçer, yani eş zamanlı çalışmazlar!
        //değişkenlere globaldan ulaşmak bilgisayar için daha uzun sürüyor
        /*Semaphore da bozuk (slim olmayan)
        2 ok için Lock kullandıktan sonra semaphoreslim'e gerek yok bu örnekte !!!!!!!!!!!!!!!!!!!!  !!!!!!!!!
        semaphoreslim() lock'tan daha kötü, lock en azından 2 ok için işe yarıyor, semapohreslim 2 ok için bile bozuk
        semaphoreslim(1,1) lock ile aynı, semaphoreslim(2) bozuk, semaphoreslim(2,2) de bozuk
        only 2 threads can access to the same thread at the same time, semaphoreslim is a lighter alternative to semaphore
        lock ve semaphore birlikte kullanılınca da olmuyor
        ReaderWriterLockSlim lock ile aynı sonucu veriyor
        ManuelResetEvent de olmuyor
        while gameloop + Console.Clear olmuyor*/
        #endregion
        #region Fields


        #endregion

        static readonly CommonGround cg = CommonGround.Cg;

        static readonly Stats st = Stats.St;
        static readonly Arrows arr = Arrows.Arr;
        static readonly GameWindowMap GWM = GameWindowMap.GWM;
        static readonly PlayerCharacter pc = PlayerCharacter.PC;
        static readonly Inputs inp = Inputs.Inp;

        public bool isPaused = false;
        public static string choosemessage = "Choose the game you want to play!";
        public static string gameChoice1 = "1. Side Scroller Game";
        public static string gameChoice2 = "2. Simple Snake Game(not playable)";
        public static char a;

        private static Lazy<Program> _pr;
        public static Program Pr
        {
            get
            {
                if (_pr == null)
                {
                    _pr = new Lazy<Program>(() => new Program());
                }
                return _pr.Value;
            }
        }

        static byte c = 0;
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Console.Clear();

            Pr.HailScreen();
            Pr.ChooseScreen();

        }
        private void PauseResumeGame()
        {
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.P && c % 2 == 0)
            {
                lock (cg.LockObject)
                {
                    Console.SetCursorPosition(46, 10);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("GAME PAUSED");
                    Console.ForegroundColor = ConsoleColor.White;
                    ++c;
                    Pr.isPaused = true;
                }
            }
            else if (key.Key == ConsoleKey.P && c % 2 != 0)
            {
                lock (cg.LockObject)
                {
                    Console.SetCursorPosition(46, 10);
                    Console.ForegroundColor = ConsoleColor.Green;
                    string message = "GAME RESUMED";
                    Console.WriteLine(message);
                    System.Threading.Thread.Sleep(2000);
                    Console.SetCursorPosition(46, 10);
                    String st = new string(' ', message.Length);
                    Console.Write(st);
                    Console.ForegroundColor = ConsoleColor.White;
                    c = 0;
                    Pr.isPaused = false;
                }
            }
            else if (key.Key == ConsoleKey.M)
            {
                lock (cg.LockObject)
                {
                    Console.Clear();
                    Pr.ChooseScreen();
                }
            }
        }

        public void ChooseScreen()
        {
            byte i = 2;
            Console.SetCursorPosition(2, 2);
            Console.WriteLine("Choose the game you want to play!");
            Console.WriteLine();
            Console.WriteLine();
            Console.SetCursorPosition(2, ++i + 1);
            Console.WriteLine("1. Side Scroller Game");
            Console.SetCursorPosition(2, ++i + 1);
            Console.WriteLine("2. Simple Snake Game(not playable)");

            byte count = 0;
        menu:
            if (count >= 1)
            {
                Thread warningscreenThread = new Thread(Pr.WarningScreen);
                warningscreenThread.Start();
            }
            a = Console.ReadKey(true).KeyChar;
            if (!Byte.TryParse(a.ToString(), out _))
            {
                byte b = 2;
                Console.SetCursorPosition(2, 2);
                Console.WriteLine("Choose the game you want to play!");
                Console.WriteLine();
                Console.WriteLine();
                Console.SetCursorPosition(2, ++b + 1);
                Console.WriteLine("1. Side Scroller Game");
                Console.SetCursorPosition(2, ++b + 1);
                Console.WriteLine("2. Simple Snake Game(not playable)");
                count++;
                goto menu;
            }
            else
            {
                Pr.GameChoice();
            }
        }
        public void GameChoice()
        {
            switch (a)
            {
                case '1':
                    Thread.Sleep(1500);
                    byte k = 2;
                    String s = new string(' ', choosemessage.Length);
                    Console.SetCursorPosition(2, 2);
                    Console.Write(s);
                    String s1 = new string(' ', gameChoice1.Length);
                    Console.SetCursorPosition(2, ++k + 1);
                    Console.Write(s1);
                    String s2 = new string(' ', gameChoice2.Length);
                    Console.SetCursorPosition(2, ++k + 1);
                    Console.Write(s2);


                    GWM.DrawGameWindow();
                    GWM.DrawFloor();
                    st.DrawStatsScore();
                    pc.DrawPlayer();
                    GWM.PauseResumeOption();
                    System.Threading.Thread.Sleep(2000);

                    Gallons.CreateGallons();

                    //10 adet gallondan birkaçı hatalı olarak hep saha dışına tepeye çiziliyor onları silmek için.
                    Gallons.DeleteFalsePlacedGallons();

                    Thread rndMoveArrowTHREAD1 = new Thread(arr.MoveArrows1);

                    Thread rndMoveArrowTHREAD2 = new Thread(arr.MoveArrows2);

                    Thread rndMoveArrowTHREAD3 = new Thread(arr.MoveArrows3);

                    Thread handleinputThread = new Thread(inp.HandleInput);

                    Thread rndLocationArrowGenTHREAD1 = new Thread(arr.RandomLocationArrowGenerator1);

                    Thread rndLocationArrowGenTHREAD2 = new Thread(arr.RandomLocationArrowGenerator2);

                    Thread rndLocationArrowGenTHREAD3 = new Thread(arr.RandomLocationArrowGenerator3);
                    Thread threadPauseResumeGame = new Thread(Pr.PauseResumeGame);
                    rndLocationArrowGenTHREAD1.Start();
                    rndLocationArrowGenTHREAD2.Start();
                    rndLocationArrowGenTHREAD3.Start();
                    rndMoveArrowTHREAD3.Start();
                    rndMoveArrowTHREAD2.Start();
                    rndMoveArrowTHREAD1.Start();
                    handleinputThread.Start();
                    threadPauseResumeGame.Start();

                    break;
                default:
                    break;

            }
        }//Ana kod
        public void GameChoice(char a)
        {
            switch (a)
            {
                case '1':

                    GWM.DrawGameWindow();
                    GWM.DrawFloor();
                    st.DrawStatsScore();
                    pc.DrawPlayer();
                    GWM.PauseResumeOption();
                    System.Threading.Thread.Sleep(2000);

                    Gallons.CreateGallons();

                    //10 adet gallondan birkaçı hatalı olarak hep saha dışına tepeye çiziliyor onları silmek için.
                    Gallons.DeleteFalsePlacedGallons();

                    Thread rndMoveArrowTHREAD1 = new Thread(arr.MoveArrows1);

                    Thread rndMoveArrowTHREAD2 = new Thread(arr.MoveArrows2);

                    Thread rndMoveArrowTHREAD3 = new Thread(arr.MoveArrows3);

                    Thread handleinputThread = new Thread(inp.HandleInput);

                    Thread rndLocationArrowGenTHREAD1 = new Thread(arr.RandomLocationArrowGenerator1);

                    Thread rndLocationArrowGenTHREAD2 = new Thread(arr.RandomLocationArrowGenerator2);

                    Thread rndLocationArrowGenTHREAD3 = new Thread(arr.RandomLocationArrowGenerator3);
                    Thread threadPauseResumeGame = new Thread(Pr.PauseResumeGame);
                    rndLocationArrowGenTHREAD1.Start();
                    rndLocationArrowGenTHREAD2.Start();
                    rndLocationArrowGenTHREAD3.Start();
                    rndMoveArrowTHREAD3.Start();
                    rndMoveArrowTHREAD2.Start();
                    rndMoveArrowTHREAD1.Start();
                    handleinputThread.Start();
                    threadPauseResumeGame.Start();

                    break;
                default:
                    break;

            }
        } //Bu sadece Stats Class'ında Restart amacıyla GameOverStartExit() metoduna konulan bir Overload.

        private void WarningScreen()
        {
            Console.SetCursorPosition(2, 1);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Please Enter a Valid Value!");
            Console.Beep();
            String warningmessage = "Please Enter a Valid Value!";
            Console.ForegroundColor = ConsoleColor.White;
            Thread.Sleep(3000);
            Console.SetCursorPosition(2, 1);
            String s = new string(' ', warningmessage.Length);
            Console.Write(s);
        }

        private void HailScreen()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            string message = "Welcome To My Game Cluster!";
            byte width = Convert.ToByte(Console.WindowWidth);
            byte height = Convert.ToByte(Console.WindowHeight);
            byte x = Convert.ToByte(Convert.ToByte((width - Convert.ToByte(message.Length)) / 2));
            byte y = Convert.ToByte(Convert.ToByte(height) / 2);
            Console.SetCursorPosition(x - 1, y - 2);
            Console.WriteLine(message);
            System.Threading.Thread.Sleep(2000);
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetCursorPosition(x - 1, y - 2);
            String s = new string(' ', message.Length);
            Console.Write(s);
        }

    }
}
