﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace SideScrollerGame
{
    internal class FireBullets
    {
        static readonly CommonGround cg = CommonGround.Cg;

        static readonly Program pr = Program.Pr;
        static readonly PlayerCharacter pc = PlayerCharacter.PC;
        public List<List<int>> bulletList = new List<List<int>>();

        private static Lazy<FireBullets> _fb;
        public static FireBullets Fb
        {
            get
            {
                if (_fb == null)
                {
                    _fb = new Lazy<FireBullets>(() => new FireBullets());
                }
                return _fb.Value;
            }
        }

        private FireBullets()
        {

        }

        public void Fire(byte[,] XY)
        {
            //initialize 2 dimentional list
            if (!pr.isPaused)
            {
                for (int j = 0; j < 100; j++)
                {
                    bulletList.Add(new List<int> { 0, 0 }); // each bullet has two values, X and Y position
                }
                int projectilePosX = pc.playerPosX + 2; // Starting X position of the projectile
                int projectilePosY = pc.playerPosY; // Y position of the projectile is the same as the player's
                int k = 0;
                while (projectilePosX < 101)
                {
                    lock (cg.LockObject)
                    {
                        // Erase the previous position of the projectile
                        lock (cg.LockObject)
                        {
                            // Move the projectile to the new position
                            //projectilePosX+1 yapsam "--" 2 adet mermi gödnderiyor ve sağ duvara ulaşabiliyor silinmiyor galonlar refresh ediyor
                            //++projectilePosX yaparsam mermi daha hızlı ilerliyor ama gallonlar refresh etmiyor(teması algılamıyor olabilirler)
                            Console.SetCursorPosition(projectilePosX, projectilePosY);
                            Console.ForegroundColor = ConsoleColor.Magenta;
                            Console.Write('-');
                            Console.ForegroundColor = ConsoleColor.White;
                            bulletList[k][0] = projectilePosX;
                            bulletList[k][1] = projectilePosY;
                            Console.SetCursorPosition(projectilePosX - 1, projectilePosY);
                            Console.Write(' ');

                            ++k;
                        }

                        if (k >= 100)
                        {
                            break;
                        }
                        lock (cg.LockObject)
                        {
                            for (int i = 0; i < XY.GetLength(0); i++)
                            {
                                if (projectilePosX - 3 == XY[i, 0] && projectilePosY == XY[i, 1])
                                {
                                    Thread RefreshGallonsHitByFireBulletsTHREAD = new Thread(() => Gallons.RefreshGallonsHitByFireBullets(XY, i));
                                    RefreshGallonsHitByFireBulletsTHREAD.Start();
                                    break;
                                }
                            }
                        }
                    }

                    Thread.Sleep(50);
                    projectilePosX++;
                    if (projectilePosX == 100)
                    {
                        Thread clearThread = new Thread(ClearRemnants.ClearBulletsOnRightWall);
                        clearThread.Start();
                    }
                } 
            }
        }
    }
}
