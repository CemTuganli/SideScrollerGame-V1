﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class GameWindowMap
    {
        static readonly CommonGround cg = CommonGround.Cg;

        //bunlar static olabilir
        private static Lazy<GameWindowMap> _gwm;
        public static GameWindowMap GWM
        {
            get
            {
                //create a singleton, if not created already
                if (_gwm == null)
                {
                    //instancing happens
                    _gwm = new Lazy<GameWindowMap>(() => new GameWindowMap());
                }
                return _gwm.Value;
            }
        }

        private GameWindowMap()
        {

        }

        public void PauseResumeOption()
        {
            lock (cg.LockObject)
            {
                byte x = 78;
                byte y = 22;
                Console.SetCursorPosition(x, y);
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("Pause: P / Main Menu: M");
                Console.ForegroundColor = ConsoleColor.White; 
            }
        }

        public void DrawGameWindow()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            const byte height = 20;
            const byte width = 100;
            Console.CursorTop = 2;
            Console.CursorLeft = 5;
            for (int j = 0; j < height; j++)
            {
                for (int i = 0; i < width; i++)
                {
                    if (j <= 1)
                    {
                        Console.Write("#");
                    }
                    else if ((j >= 1 && i <= 2) || (j > 1 && i >= 97))
                    {
                        Console.Write("#");
                    }
                    else if (j > 17)
                    {
                        Console.Write("#");
                    }
                    else
                    {
                        Console.Write(" ");
                    }
                }
                Console.CursorLeft = 5;
                ++Console.CursorTop;
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        public void DrawFloor()
        {
            lock (cg.LockObject)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.CursorTop = 19;
                Console.CursorLeft = 8;
                string floor = new string('_', 94);
                Console.Write(floor);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    }
}
