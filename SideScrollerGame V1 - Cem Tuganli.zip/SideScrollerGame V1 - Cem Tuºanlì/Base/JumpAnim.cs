﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SideScrollerGame
{
    public class JumpAnim
    {
        static readonly CommonGround cg = CommonGround.Cg;

        static readonly Program pr = Program.Pr;
        static readonly PlayerCharacter pc = PlayerCharacter.PC;

        private static Lazy<JumpAnim> _ja;
        public static JumpAnim Ja
        {
            get
            {
                if (_ja == null)
                {
                    _ja = new Lazy<JumpAnim>(() => new JumpAnim());
                }
                return _ja.Value;
            }
        }

        private JumpAnim()
        {

        }

        public void Jump()
        {
            bool landing = false;
            if (!pr.isPaused)
            {
                while (!landing)
                {
                    //nereye ve ne kadarlık alana lock koyduğuna dikkat et yoksa oyun gereksiz kasar
                    lock (cg.LockObject)
                    {
                        // Erase the previous position of the player
                        Console.SetCursorPosition(pc.playerPosX, pc.playerPosY);
                        Console.Write(' ');

                        // Move the player to the new position
                        Console.SetCursorPosition(pc.playerPosX, --pc.playerPosY);
                        Console.Write('0');
                    }

                    Thread.Sleep(100);
                    if (pc.playerPosY == 9)
                    {
                        while (!landing)
                        {
                            lock (cg.LockObject)
                            {
                                // Erase the previous position of the player
                                Console.SetCursorPosition(pc.playerPosX, pc.playerPosY);
                                Console.Write(' ');

                                // Move the player to the new position
                                Console.SetCursorPosition(pc.playerPosX, ++pc.playerPosY);
                                Console.Write('0');
                            }
                            Thread.Sleep(100);
                            if (pc.playerPosY == 18)
                            {
                                landing = true;
                            }
                        }
                    }
                } 
            }
        }
    }
}
